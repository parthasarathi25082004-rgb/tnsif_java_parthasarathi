**How to Download - Spring Boot \& Postman API**





**Official site:** https://spring.io/projects/spring-boot



**How to download**



https://spring.io/tools custom by user -> download \& extract

Open spring tool suite (application) -> -> File -> New -> Spring Starter project

&nbsp;

**Spring Starter project dialogue box**



Name: 

Type: Maven

Version: 17

Package: Jar

Language: Java



Spring Starter project dialogue box -> Next -> choose -> finish



**DI need to be added :**



JDBC API

Spring Data JPA

PostgreSQL Driver

Rest Repositories

Spring web





**Notes on PostMan**



**Postman API Download ->** Link: https://www.postman.com/downloads/





HTTP Requests -> GET, POST, PUT, DELETE



**Steps:**



1\. New -> HTTP -> write the URL 

&nbsp;                      Eg: http://localhost:8080/employee



2\. To get particular data, delete particular data

&nbsp;                       Eg: http://localhost:8080/employee/3

